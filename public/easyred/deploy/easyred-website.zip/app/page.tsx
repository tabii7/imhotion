import EasyredWebsite from "@/components/easyred-website"

export default function Page() {
  return <EasyredWebsite />
}
